import React, { useContext, useMemo, useState } from 'react'
import Layout from '../components/Layout/Layout'
import { IssueContext } from '../contexts/IssueContext'
import EngagementButtons from '../components/Common/EngagementButtons'
import { calcEngagement } from '../utils/helpers'
import CitizenEditModal from '../components/Modals/CitizenEditModal'
import AdminModal from '../components/Modals/AdminModal'
import { AuthContext } from '../contexts/AuthContext'

const categories = ['All', 'General', 'Transportation', 'Safety', 'Infrastructure', 'Sanitation', 'Other']

export default function Community(){
  const { issues, deleteIssue } = useContext(IssueContext)
  const { currentUser } = useContext(AuthContext)
  const [editing, setEditing] = useState(null)
  const [adminEditing, setAdminEditing] = useState(null)
  const [categoryFilter, setCategoryFilter] = useState('All')

  const filteredIssues = useMemo(() => {
    if (categoryFilter === 'All') return issues
    return issues.filter(issue => issue.category === categoryFilter)
  }, [categoryFilter, issues])

  return (
    <Layout>
      <div className="glass p-6 bg-white/90 text-slate-900">
        <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
          <div>
            <h2 className="text-3xl font-bold">Community Board</h2>
            <p className="text-slate-600 mt-2">Browse all submitted issues, interact with the community, and track engagement in real time.</p>
          </div>
          <div className="flex items-center gap-3">
            <label className="text-slate-600">Filter by category:</label>
            <select value={categoryFilter} onChange={e=>setCategoryFilter(e.target.value)} className="p-2 rounded border border-slate-300 bg-white">
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-5">
          {filteredIssues.length === 0 && (
            <div className="glass-card p-5 bg-white/90 text-slate-900">
              No issues found for this category.
            </div>
          )}

          {filteredIssues.map(issue => (
            <div key={issue.id} className="glass-card p-6 bg-white/90 text-slate-900 border border-slate-200">
              <div className="flex flex-col lg:flex-row justify-between gap-4">
                <div>
                  <div className="text-2xl font-bold">{issue.title}</div>
                  <div className="text-sm text-slate-500 mt-1">Category: {issue.category} • Submitted by: {issue.anonymous ? 'Anonymous' : issue.createdBy?.name || 'Unknown'} • {issue.incidentDate || 'No date provided'}</div>
                </div>
                <div className="space-y-2 text-right">
                  <div className={issue.priority==='High'? 'priority-high': issue.priority==='Medium'? 'priority-medium': 'priority-low'}>{issue.priority}</div>
                  <div className={issue.status==='Resolved'? 'status-resolved': issue.status==='In Progress'? 'status-inprogress':'status-pending'}>{issue.status}</div>
                  <div className="text-sm text-slate-500">Score: {calcEngagement(issue)}</div>
                </div>
              </div>

              <div className="mt-4 space-y-3">
                <p>{issue.description}</p>
                <div className="text-sm text-slate-600">Location: {issue.location || 'Not specified'}</div>
                <div className="text-sm text-slate-600">Suggested improvement: {issue.suggestedImprovement || 'None provided'}</div>
                <div className="flex flex-wrap gap-3 text-sm text-slate-600">
                  <span>Experience: {issue.experience}/5</span>
                  <span>Efficiency: {issue.efficiency}/5</span>
                </div>
                {issue.adminNote && <div className="rounded-lg bg-slate-100 p-3 text-slate-700">Admin note: {issue.adminNote}</div>}
                {issue.addressedBy && <div className="text-sm text-slate-600">Addressed by: {issue.addressedBy}</div>}
              </div>

              <div className="mt-4 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  <EngagementButtons issue={issue} />
                </div>
                <div className="flex flex-wrap gap-2">
                  {currentUser && currentUser.id === issue.createdBy?.id && issue.status !== 'Resolved' && (
                    <button onClick={()=>setEditing(issue)} className="btn-primary">Edit</button>
                  )}
                  {currentUser?.role === 'admin' && (
                    <>
                      <button onClick={()=>setAdminEditing(issue)} className="btn-primary">Admin Edit</button>
                      <button className="btn-danger" onClick={()=>deleteIssue(issue.id)}>Delete</button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/70 backdrop-blur-sm">
          <CitizenEditModal issue={editing} onClose={()=>setEditing(null)} />
        </div>
      )}
      {adminEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/70 backdrop-blur-sm">
          <AdminModal issue={adminEditing} onClose={()=>setAdminEditing(null)} />
        </div>
      )}
    </Layout>
  )
}
