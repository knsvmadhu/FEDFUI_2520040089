import React, { useState, useContext } from 'react'
import { IssueContext } from '../../contexts/IssueContext'
import { NotificationContext } from '../../contexts/NotificationContext'

export default function CitizenEditModal({issue, onClose}){
  const { updateIssue, deleteIssue } = useContext(IssueContext)
  const { push } = useContext(NotificationContext)
  const [form, setForm] = useState({...issue})

  const save = ()=>{
    updateIssue(issue.id, form)
    push('Issue updated','Your changes were saved')
    onClose()
  }

  const remove = ()=>{
    deleteIssue(issue.id)
    push('Issue deleted','Your issue was removed')
    onClose()
  }

  return (
    <div className="glass p-4">
      <h3 className="font-bold">Edit Issue</h3>
      <input className="p-2 bg-white/5 rounded mt-2" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} />
      <textarea className="p-2 bg-white/5 rounded mt-2" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} />
      <div className="flex gap-2 mt-2">
        <button className="btn-primary" onClick={save}>Save</button>
        <button className="btn-danger" onClick={remove}>Delete</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  )
}
