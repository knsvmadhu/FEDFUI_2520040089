import React, { useContext, useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { AuthContext } from '../../contexts/AuthContext'
import { Bell, LogOut } from 'lucide-react'
import NotificationPanel from '../Common/NotificationPanel'

export default function Navbar(){
  const { currentUser, logout } = useContext(AuthContext)
  const [showNotifications, setShowNotifications] = useState(false)
  const nav = useNavigate()

  return (
    <div className="glass flex items-center justify-between p-3 mb-6">
      <div className="flex items-center gap-4">
        <Link to="/" className="text-xl font-bold">Smart Citizen Feedback and Public Issue Tracking System</Link>
        <NavLink to="/community" className={({isActive})=>isActive? 'underline':''}>Community</NavLink>
        <NavLink to="/feedback" className={({isActive})=>isActive? 'underline':''}>Submit Issue</NavLink>
        {currentUser && <NavLink to="/dashboard" className={({isActive})=>isActive? 'underline':''}>Dashboard</NavLink>}
        {currentUser?.role==='admin' && <NavLink to="/admin" className={({isActive})=>isActive? 'underline':''}>Admin</NavLink>}
      </div>
      <div className="flex items-center gap-4">
        <button className="relative" onClick={()=>setShowNotifications(s=>!s)} aria-label="notifications">
          <Bell />
        </button>
        {showNotifications && <NotificationPanel onClose={()=>setShowNotifications(false)} />}
        {!currentUser ? (
          <Link to="/feedback" className="btn-primary">Login / Register</Link>
        ) : (
          <div className="flex items-center gap-2">
            <div className="text-sm">{currentUser.name} ({currentUser.role})</div>
            <button className="btn-danger" onClick={()=>{logout(); nav('/')}}><LogOut size={16}/> Logout</button>
          </div>
        )}
      </div>
    </div>
  )
}
