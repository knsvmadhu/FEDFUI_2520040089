import React, { useContext, useState } from 'react'
import Layout from '../components/Layout/Layout'
import { AuthContext } from '../contexts/AuthContext'

export default function Users(){
  const { users, deleteUser } = useContext(AuthContext)
  const [q, setQ] = useState('')
  const list = users.filter(u=> u.name.toLowerCase().includes(q.toLowerCase()) || u.email.toLowerCase().includes(q.toLowerCase()))
  return (
    <Layout>
      <div className="glass p-4">
        <h2 className="font-bold">Users</h2>
        <input placeholder="Search" value={q} onChange={e=>setQ(e.target.value)} className="p-2 bg-white/5 rounded mt-2" />
        <div className="mt-2">
          {list.map(u=> (
            <div key={u.id} className="glass-card p-3 flex justify-between items-center">
              <div>
                <div className="font-bold">{u.name}</div>
                <div className="text-sm text-gray-300">{u.email} • {u.role}</div>
              </div>
              <div><button className="btn-danger" onClick={()=>deleteUser(u.id)}>Delete</button></div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}
