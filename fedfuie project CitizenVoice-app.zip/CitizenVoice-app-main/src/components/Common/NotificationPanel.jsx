import React, { useContext } from 'react'
import { NotificationContext } from '../../contexts/NotificationContext'

export default function NotificationPanel({onClose}){
  const { notifications, clearAll } = useContext(NotificationContext)
  return (
    <div className="glass absolute right-4 mt-12 w-80 p-3">
      <div className="flex justify-between items-center mb-2">
        <div className="font-bold">Notifications</div>
        <div className="text-xs text-gray-300 cursor-pointer" onClick={clearAll}>Clear</div>
      </div>
      <div className="max-h-64 overflow-auto">
        {notifications.length===0 && <div className="text-sm text-gray-400">No notifications</div>}
        {notifications.map(n=> (
          <div key={n.id} className="mb-2">
            <div className="font-semibold">{n.title}</div>
            <div className="text-sm text-gray-300">{n.message}</div>
          </div>
        ))}
      </div>
      <div className="text-right mt-2"><button onClick={onClose} className="text-sm">Close</button></div>
    </div>
  )
}
