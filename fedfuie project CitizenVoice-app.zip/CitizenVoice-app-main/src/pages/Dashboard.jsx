import React, { useContext } from 'react'
import Layout from '../components/Layout/Layout'
import { IssueContext } from '../contexts/IssueContext'
import { AuthContext } from '../contexts/AuthContext'

export default function Dashboard(){
  const { issues } = useContext(IssueContext)
  const { currentUser } = useContext(AuthContext)
  const mine = issues.filter(i=> i.createdBy?.id === currentUser?.id)
  return (
    <Layout>
      <div className="glass p-4">
        <h2 className="font-bold">Dashboard</h2>
        <div className="mt-2">Total issues: {issues.length}</div>
        <div className="mt-4">
          <h3>Your recent issues</h3>
          {mine.length===0 && <div className="text-sm text-gray-400">No submissions yet</div>}
          {mine.map(i=> (
            <div key={i.id} className="glass-card p-3">
              <div className="font-bold">{i.title}</div>
              <div className="text-sm">{i.status} • {i.priority}</div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}
