import React, { useContext } from 'react'
import Layout from '../components/Layout/Layout'
import { IssueContext } from '../contexts/IssueContext'

export default function Resolved(){
  const { issues } = useContext(IssueContext)
  const resolved = issues.filter(i=> i.status==='Resolved')
  return (
    <Layout>
      <div className="glass p-4">
        <h2 className="font-bold">Resolved Issues</h2>
        {resolved.map(r=> (
          <div key={r.id} className="glass-card p-3">
            <div className="font-bold">{r.title}</div>
            <div className="text-sm">{r.description}</div>
            <div className="text-xs text-gray-300">Addressed by: {r.addressedBy || '—'}</div>
          </div>
        ))}
      </div>
    </Layout>
  )
}
