import React, { useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import Feedback from './pages/Feedback'
import Community from './pages/Community'
import Resolved from './pages/Resolved'
import AdminPanel from './pages/AdminPanel'
import TopIssues from './pages/TopIssues'
import Users from './pages/Users'
import ProtectedRoute from './components/Common/ProtectedRoute'
import { seedDefaults } from './services/dataService'

export default function App(){
  useEffect(()=>{ seedDefaults() },[])

  return (
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/dashboard" element={<ProtectedRoute><Dashboard/></ProtectedRoute>} />
      <Route path="/feedback" element={<Feedback/>} />
      <Route path="/community" element={<Community/>} />
      <Route path="/resolved" element={<Resolved/>} />
      <Route path="/admin" element={<ProtectedRoute adminOnly={true}><AdminPanel/></ProtectedRoute>} />
      <Route path="/top" element={<ProtectedRoute adminOnly={true}><TopIssues/></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute adminOnly={true}><Users/></ProtectedRoute>} />
    </Routes>
  )
}
