import React from 'react'
import Navbar from './Navbar'

export default function Layout({children}){
  return (
    <div className="app-root">
      <Navbar />
      <div className="container mx-auto">{children}</div>
    </div>
  )
}
