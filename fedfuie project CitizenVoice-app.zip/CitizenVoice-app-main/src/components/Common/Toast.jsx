import React, { useContext } from 'react'
import { NotificationContext } from '../../contexts/NotificationContext'

export default function Toast(){
  const { notifications } = useContext(NotificationContext)
  if(!notifications.length) return null
  return (
    <div className="toast">
      {notifications.slice(0,3).map(n=> (
        <div key={n.id} className="glass-card p-3 mb-2"> 
          <div className="font-bold">{n.title}</div>
          <div className="text-sm">{n.message}</div>
        </div>
      ))}
    </div>
  )
}
