/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,jsx,ts,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: '#6c5ce7',
        glass: 'rgba(255,255,255,0.08)'
      }
    }
  },
  plugins: [],
}
