import React, { useContext } from 'react'
import { Navigate } from 'react-router-dom'
import { AuthContext } from '../../contexts/AuthContext'

export default function ProtectedRoute({children, adminOnly}){
  const { currentUser } = useContext(AuthContext)
  if(!currentUser) return <Navigate to="/" replace />
  if(adminOnly && currentUser.role!=='admin') return <Navigate to="/" replace />
  return children
}
