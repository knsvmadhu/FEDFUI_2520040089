import React, { createContext, useState } from 'react'
import { STORAGE_KEYS } from '../utils/constants'

export const NotificationContext = createContext()

export const NotificationProvider = ({children})=>{
  const [notifications, setNotifications] = useState(()=>{
    try{ const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS); return raw? JSON.parse(raw): [] }catch(e){return []}
  })

  const push = (title, message)=>{
    const n = {id: Date.now().toString(), title, message, date: new Date().toISOString()}
    const next = [n, ...notifications].slice(0,50)
    setNotifications(next)
    try{ localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(next)) }catch(e){}
  }

  const clearAll = ()=>{ setNotifications([]); localStorage.removeItem(STORAGE_KEYS.NOTIFICATIONS) }

  return (
    <NotificationContext.Provider value={{notifications, push, clearAll}}>
      {children}
    </NotificationContext.Provider>
  )
}
