import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useIssues } from '../contexts/IssueContext';
import LoginModal from '../components/Modals/LoginModal';

const Home = () => {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginRole, setLoginRole] = useState('citizen');
  const { user } = useAuth();
  const { issues } = useIssues();

  useEffect(() => {
    if (user) window.location.href = '/dashboard';
  }, [user]);

  const total = issues.length;
  const resolved = issues.filter(i => i.status === 'Resolved').length;
  const inProgress = issues.filter(i => i.status === 'In Progress').length;
  const pending = issues.filter(i => i.status === 'Pending').length;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 py-20 bg-gradient-to-b from-purple-50/50 to-transparent">
      {/* Subtitle */}
      <p className="text-purple-600 font-semibold tracking-wide text-lg mb-3">Smart Citizen Feedback and Public Issue Tracking System</p>

      {/* Main Title */}
      <h1 className="font-outfit font-extrabold text-3xl sm:text-4xl md:text-5xl bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent max-w-4xl text-center leading-tight">
        Smart Citizen Feedback and Public Issue Tracking System
      </h1>

      {/* Description (optional, matches your fourth image) */}
      <p className="mt-6 text-gray-600 max-w-xl text-center">
        A civic engagement platform for citizens and administrators to report public issues,
        share feedback, and track resolution progress in one transparent system.
      </p>

      {/* Buttons */}
      <div className="flex gap-4 mt-8">
        <button onClick={() => { setLoginRole('citizen'); setShowLoginModal(true); }} className="btn-primary px-6 py-2 rounded-2xl">Citizen</button>
        <button onClick={() => { setLoginRole('admin'); setShowLoginModal(true); }} className="btn-secondary px-6 py-2 rounded-2xl">Admin</button>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap justify-center gap-8 mt-12">
        <div className="text-center"><p className="text-3xl font-bold text-purple-500">{total}</p><p className="text-xs text-gray-500">Issues Raised</p></div>
        <div className="text-center"><p className="text-3xl font-bold text-green-500">{resolved}</p><p className="text-xs text-gray-500">Resolved</p></div>
        <div className="text-center"><p className="text-3xl font-bold text-blue-500">{inProgress}</p><p className="text-xs text-gray-500">In Progress</p></div>
        <div className="text-center"><p className="text-3xl font-bold text-yellow-500">{pending}</p><p className="text-xs text-gray-500">Pending</p></div>
      </div>

      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} defaultRole={loginRole} />
    </div>
  );
};

export default Home;