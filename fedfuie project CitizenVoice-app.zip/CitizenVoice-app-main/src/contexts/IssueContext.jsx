import React, { createContext, useEffect, useState, useContext } from 'react'
import { STORAGE_KEYS } from '../utils/constants'
import { uid } from '../utils/helpers'
import { AuthContext } from './AuthContext'

export const IssueContext = createContext()

export const IssueProvider = ({children})=>{
  const { currentUser } = useContext(AuthContext)
  const [issues, setIssues] = useState(()=>{
    try{ const raw = localStorage.getItem(STORAGE_KEYS.ISSUES); return raw? JSON.parse(raw): [] }catch(e){return []}
  })

  useEffect(()=>{ localStorage.setItem(STORAGE_KEYS.ISSUES, JSON.stringify(issues)) },[issues])

  const addIssue = (payload)=>{
    const issue = {
      id: uid(),
      createdAt: new Date().toISOString(),
      createdBy: currentUser? {id: currentUser.id, name: currentUser.name} : null,
      upvotes: 0, agrees: 0, disagrees:0, likes:0,
      status: 'Pending',
      ...payload
    }
    setIssues([issue, ...issues])
    return issue
  }

  const updateIssue = (id, patch)=>{
    setIssues(issues.map(i=> i.id===id ? {...i, ...patch} : i))
  }

  const deleteIssue = (id)=> setIssues(issues.filter(i=> i.id!==id))

  const bulkUpdateStatus = (ids, status)=> setIssues(issues.map(i=> ids.includes(i.id)? {...i, status}: i))

  const engage = (id, type)=>{
    setIssues(issues.map(i=>{
      if(i.id!==id) return i
      const next = {...i}
      if(type==='upvote') next.upvotes = (next.upvotes||0)+1
      if(type==='agree') next.agrees = (next.agrees||0)+1
      if(type==='disagree') next.disagrees = (next.disagrees||0)+1
      if(type==='like') next.likes = (next.likes||0)+1
      return next
    }))
  }

  return (
    <IssueContext.Provider value={{issues, addIssue, updateIssue, deleteIssue, bulkUpdateStatus, engage}}>
      {children}
    </IssueContext.Provider>
  )
}
