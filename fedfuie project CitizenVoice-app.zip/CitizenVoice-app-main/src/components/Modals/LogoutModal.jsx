import React from 'react'

export default function LogoutModal({onClose, onConfirm}){
  return (
    <div className="glass p-4">
      <h3 className="font-bold">Logout</h3>
      <div className="mt-2">Are you sure you want to logout?</div>
      <div className="flex gap-2 mt-3">
        <button className="btn-primary" onClick={onConfirm}>Yes</button>
        <button onClick={onClose}>No</button>
      </div>
    </div>
  )
}
