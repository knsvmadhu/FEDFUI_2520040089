import React, { createContext, useEffect, useState } from 'react'
import { STORAGE_KEYS } from '../utils/constants'
import { uid } from '../utils/helpers'

export const AuthContext = createContext()

export const AuthProvider = ({children})=>{
  const [users, setUsers] = useState(()=>{
    try{ const raw = localStorage.getItem(STORAGE_KEYS.USERS); return raw? JSON.parse(raw): [] }catch(e){return []}
  })
  const [currentUser, setCurrentUser] = useState(()=>{
    try{ const raw = localStorage.getItem(STORAGE_KEYS.CURRENT_USER); return raw? JSON.parse(raw): null }catch(e){return null}
  })

  useEffect(()=>{ localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users)) },[users])
  useEffect(()=>{ if(currentUser) localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(currentUser)); else localStorage.removeItem(STORAGE_KEYS.CURRENT_USER) },[currentUser])

  const register = ({name,email,password})=>{
    if(users.find(u=>u.email===email)) return { error: 'Email already exists' }
    const user = { id: uid(), name, email, password, role: 'citizen' }
    const next = [user, ...users]
    setUsers(next)
    setCurrentUser(user)
    return { user }
  }

  const login = ({email,password})=>{
    const u = users.find(x=>x.email===email && x.password===password)
    if(!u) return { error: 'Invalid credentials' }
    setCurrentUser(u)
    return { user: u }
  }

  const logout = ()=> setCurrentUser(null)

  const deleteUser = (id)=>{
    const next = users.filter(u=>u.id!==id)
    setUsers(next)
    if(currentUser?.id===id) setCurrentUser(null)
  }

  const updateUser = (id, patch)=>{
    const next = users.map(u=> u.id===id ? {...u, ...patch} : u)
    setUsers(next)
    if(currentUser?.id===id) setCurrentUser({...currentUser, ...patch})
  }

  return (
    <AuthContext.Provider value={{users, currentUser, register, login, logout, deleteUser, updateUser}}>
      {children}
    </AuthContext.Provider>
  )
}
