export const STORAGE_KEYS = {
  USERS: 'cv_users',
  ISSUES: 'cv_issues',
  CURRENT_USER: 'cv_current_user',
  NOTIFICATIONS: 'cv_notifications'
}
