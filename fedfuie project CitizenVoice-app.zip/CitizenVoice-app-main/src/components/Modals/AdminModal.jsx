import React, { useState, useContext } from 'react'
import { IssueContext } from '../../contexts/IssueContext'
import { NotificationContext } from '../../contexts/NotificationContext'

export default function AdminModal({issue, onClose}){
  const { updateIssue } = useContext(IssueContext)
  const { push } = useContext(NotificationContext)
  const [form, setForm] = useState({...issue, adminNote: issue.adminNote||'', addressedBy: issue.addressedBy||''})

  const save = ()=>{
    updateIssue(issue.id, { status: form.status, priority: form.priority, adminNote: form.adminNote, addressedBy: form.addressedBy })
    push('Issue updated','Admin changes saved')
    onClose()
  }

  return (
    <div className="glass p-4">
      <h3 className="font-bold">Admin Edit</h3>
      <div className="mt-2">
        <label>Status</label>
        <select value={form.status} onChange={e=>setForm({...form,status:e.target.value})} className="p-2 bg-white/5 rounded w-full">
          <option>Pending</option>
          <option>In Progress</option>
          <option>Resolved</option>
        </select>
      </div>
      <div className="mt-2">
        <label>Priority</label>
        <select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})} className="p-2 bg-white/5 rounded w-full">
          <option>Low</option>
          <option>Medium</option>
          <option>High</option>
        </select>
      </div>
      <div className="mt-2">
        <label>Admin Note</label>
        <textarea value={form.adminNote} onChange={e=>setForm({...form,adminNote:e.target.value})} className="p-2 bg-white/5 rounded w-full" />
      </div>
      <div className="mt-2">
        <label>Addressed By</label>
        <input value={form.addressedBy} onChange={e=>setForm({...form,addressedBy:e.target.value})} className="p-2 bg-white/5 rounded w-full" />
      </div>
      <div className="flex gap-2 mt-3">
        <button className="btn-primary" onClick={save}>Save</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  )
}
