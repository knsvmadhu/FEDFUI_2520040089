import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useIssues } from '../contexts/IssueContext';
import { useNotification } from '../contexts/NotificationContext';

const Feedback = () => {
  const { user } = useAuth();
  const { createIssue } = useIssues();
  const { addNotification } = useNotification();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Roads',
    department: 'Roads & Infrastructure',
    priority: 'High',
    location: '',
    incident_date: '',
    suggested_improvement: '',
    is_anonymous: false,
    anonymous_alias: '',
    experience: 3,
    efficiency: 3,
    author: '',
    author_email: ''
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user || user.role === 'admin') {
      alert('Only citizens can submit issues');
      return;
    }

    const newIssue = {
      ...formData,
      author: formData.is_anonymous ? '' : (formData.author || user.name),
      author_email: formData.is_anonymous ? user.email : (formData.author_email || user.email),
      status: 'Pending',
      upvotes: 0,
      agrees: 0,
      disagrees: 0,
      likes: 0,
      created_at: new Date().toISOString()
    };

    const result = await createIssue(newIssue);
    if (result.isOk) {
      addNotification(`New issue: "${newIssue.title}"`);
      alert('Issue submitted successfully!');
      // Reset form
      setFormData({
        title: '', description: '', category: 'Roads', department: 'Roads & Infrastructure',
        priority: 'High', location: '', incident_date: '', suggested_improvement: '',
        is_anonymous: false, anonymous_alias: '', experience: 3, efficiency: 3,
        author: '', author_email: ''
      });
    } else {
      alert('Submission failed');
    }
  };

  if (!user || user.role !== 'citizen') {
    return <div className="text-center py-20">You must be logged in as a citizen to submit issues.</div>;
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-8" style={{ paddingTop: '80px' }}>
      <h2 className="font-outfit font-bold text-2xl mb-2">📝 Submit an Issue</h2>
      <p className="text-sm mb-6 text-gray-400">Report a community issue with details so the right people can review and resolve it.</p>

      <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 space-y-6">
        {/* Personal Info */}
        <div>
          <h3 className="font-semibold text-sm mb-4">Personal Information</h3>
          <div className="space-y-4">
            {!formData.is_anonymous && (
              <>
                <div><label className="block text-xs font-semibold mb-1.5">Full Name</label>
                <input type="text" name="author" value={formData.author} onChange={handleChange} className="w-full px-4 py-2.5 rounded-xl text-sm border" required /></div>
                <div><label className="block text-xs font-semibold mb-1.5">Email Address</label>
                <input type="email" name="author_email" value={formData.author_email} onChange={handleChange} className="w-full px-4 py-2.5 rounded-xl text-sm border" required /></div>
              </>
            )}
            <div className="flex items-center gap-3">
              <input type="checkbox" name="is_anonymous" checked={formData.is_anonymous} onChange={handleChange} className="w-4 h-4 rounded" />
              <label className="text-xs">Submit Anonymously</label>
            </div>
            {formData.is_anonymous && (
              <div><label className="block text-xs font-semibold mb-1.5">Anonymous Alias</label>
              <input type="text" name="anonymous_alias" value={formData.anonymous_alias} onChange={handleChange} placeholder="How should we call you?" className="w-full px-4 py-2.5 rounded-xl text-sm border" /></div>
            )}
          </div>
        </div>

        {/* Issue Details */}
        <div className="border-t pt-4">
          <h3 className="font-semibold text-sm mb-4">Issue Details</h3>
          <div className="space-y-4">
            <div><label className="block text-xs font-semibold mb-1.5">Issue Title</label>
            <input type="text" name="title" value={formData.title} onChange={handleChange} required className="w-full px-4 py-2.5 rounded-xl text-sm border" /></div>
            <div><label className="block text-xs font-semibold mb-1.5">Detailed Description</label>
            <textarea name="description" value={formData.description} onChange={handleChange} rows="4" required className="w-full px-4 py-2.5 rounded-xl text-sm border"></textarea></div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className="block text-xs font-semibold mb-1.5">Department</label>
              <select name="department" value={formData.department} onChange={handleChange} className="w-full px-3 py-2 rounded-xl text-sm border">
                <option>Roads & Infrastructure</option><option>Water & Sanitation</option><option>Electricity & Energy</option>
              </select></div>
              <div><label className="block text-xs font-semibold mb-1.5">Category</label>
              <select name="category" value={formData.category} onChange={handleChange} className="w-full px-3 py-2 rounded-xl text-sm border">
                <option>Roads</option><option>Water</option><option>Electricity</option><option>Sanitation</option><option>Health</option><option>Other</option>
              </select></div>
              <div><label className="block text-xs font-semibold mb-1.5">Priority</label>
              <select name="priority" value={formData.priority} onChange={handleChange} className="w-full px-3 py-2 rounded-xl text-sm border">
                <option>Low</option><option>Medium</option><option>High</option>
              </select></div>
            </div>
            <div><label className="block text-xs font-semibold mb-1.5">Location / Area</label>
            <input type="text" name="location" value={formData.location} onChange={handleChange} required className="w-full px-4 py-2.5 rounded-xl text-sm border" /></div>
            <div><label className="block text-xs font-semibold mb-1.5">Date of Incident</label>
            <input type="date" name="incident_date" value={formData.incident_date} onChange={handleChange} required className="w-full px-4 py-2.5 rounded-xl text-sm border" /></div>
            <div><label className="block text-xs font-semibold mb-1.5">Suggested Improvement</label>
            <textarea name="suggested_improvement" value={formData.suggested_improvement} onChange={handleChange} rows="2" className="w-full px-4 py-2.5 rounded-xl text-sm border"></textarea></div>
            <div><label className="block text-xs font-semibold mb-2">Overall Experience</label>
            <div className="flex gap-2">
              {[1,2,3,4,5].map(v => (
                <label key={v} className="flex items-center gap-1"><input type="radio" name="experience" value={v} checked={formData.experience == v} onChange={handleChange} /> {v === 1 ? '😞' : v === 2 ? '😕' : v === 3 ? '😐' : v === 4 ? '🙂' : '😊'}</label>
              ))}
            </div></div>
            <div><label className="block text-xs font-semibold mb-2">Service Efficiency</label>
            <div className="flex gap-2">
              {[1,2,3,4,5].map(v => (
                <label key={v} className="flex items-center gap-1"><input type="radio" name="efficiency" value={v} checked={formData.efficiency == v} onChange={handleChange} /> {v === 1 ? 'Very Slow' : v === 2 ? 'Slow' : v === 3 ? 'Fair' : v === 4 ? 'Fast' : 'Very Fast'}</label>
              ))}
            </div></div>
          </div>
        </div>

        <button type="submit" className="btn-primary w-full py-3 rounded-2xl font-semibold">Submit Feedback</button>
      </form>
    </div>
  );
};

export default Feedback;