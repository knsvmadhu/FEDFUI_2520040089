import React, { useContext, useState } from 'react'
import { AuthContext } from '../../contexts/AuthContext'
import { NotificationContext } from '../../contexts/NotificationContext'

export default function LoginModal(){
  const { login, register } = useContext(AuthContext)
  const { push } = useContext(NotificationContext)
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({name:'',email:'',password:''})

  const handle = async (e)=>{
    e.preventDefault()
    if(mode==='login'){
      const res = login({email: form.email, password: form.password})
      if(res.error) return push('Login failed', res.error)
      push('Logged in', `Welcome back ${res.user.name}`)
      window.location.reload()
    }else{
      const res = register({name: form.name, email: form.email, password: form.password})
      if(res.error) return push('Register failed', res.error)
      push('Registered', `Welcome ${res.user.name}`)
      window.location.reload()
    }
  }

  return (
    <div className="glass p-4">
      <div className="flex gap-4 mb-4">
        <button onClick={()=>setMode('login')} className={mode==='login'? 'underline':''}>Login</button>
        <button onClick={()=>setMode('register')} className={mode==='register'? 'underline':''}>Register</button>
      </div>
      <form onSubmit={handle} className="flex flex-col gap-2">
        {mode==='register' && <input placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="p-2 rounded bg-white/5" />}
        <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="p-2 rounded bg-white/5" />
        <input placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} className="p-2 rounded bg-white/5" />
        <button className="btn-primary mt-2" type="submit">{mode==='login'?'Login':'Register'}</button>
      </form>
    </div>
  )
}
