import { useContext } from 'react'
import { NotificationContext } from '../contexts/NotificationContext'

export default function useToast(){
  const { push } = useContext(NotificationContext)
  return push
}
