import React, { useContext } from 'react'
import { IssueContext } from '../../contexts/IssueContext'

export default function EngagementButtons({issue}){
  const { engage } = useContext(IssueContext)
  return (
    <div className="flex items-center">
      <button className="engage-btn" onClick={()=>engage(issue.id,'upvote')}>⬆ {issue.upvotes||0}</button>
      <button className="engage-btn" onClick={()=>engage(issue.id,'agree')}>🤝 {issue.agrees||0}</button>
      <button className="engage-btn" onClick={()=>engage(issue.id,'disagree')}>✋ {issue.disagrees||0}</button>
      <button className="engage-btn" onClick={()=>engage(issue.id,'like')}>❤ {issue.likes||0}</button>
    </div>
  )
}
