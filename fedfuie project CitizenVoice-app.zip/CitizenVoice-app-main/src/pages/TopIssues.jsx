import React, { useContext } from 'react'
import Layout from '../components/Layout/Layout'
import { IssueContext } from '../contexts/IssueContext'
import { calcEngagement } from '../utils/helpers'

export default function TopIssues(){
  const { issues } = useContext(IssueContext)
  const sorted = [...issues].sort((a,b)=> calcEngagement(b)-calcEngagement(a)).slice(0,10)
  return (
    <Layout>
      <div className="glass p-4">
        <h2 className="font-bold">Top Issues</h2>
        {sorted.map(i=> (
          <div key={i.id} className="glass-card p-3">
            <div className="font-bold">{i.title}</div>
            <div className="text-sm">Score: {calcEngagement(i)}</div>
          </div>
        ))}
      </div>
    </Layout>
  )
}
