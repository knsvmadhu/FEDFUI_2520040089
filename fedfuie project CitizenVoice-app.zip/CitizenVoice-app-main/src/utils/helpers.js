export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,8)

export function calcEngagement(issue){
  return (issue.upvotes||0) + (issue.agrees||0) + (issue.likes||0) - (issue.disagrees||0)
}
