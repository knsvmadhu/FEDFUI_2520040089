import { STORAGE_KEYS } from '../utils/constants'

export const read = (key)=>{
  try{ const raw = localStorage.getItem(key); return raw? JSON.parse(raw): null }catch(e){return null}
}

export const write = (key, value)=>{
  try{ localStorage.setItem(key, JSON.stringify(value)) }catch(e){}
}

export const clearKey = (key)=>{ localStorage.removeItem(key) }

export const initIfEmpty = (key, value)=>{
  if(!localStorage.getItem(key)) write(key,value)
}
