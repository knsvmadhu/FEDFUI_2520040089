import React, { useContext, useState } from 'react'
import Layout from '../components/Layout/Layout'
import { IssueContext } from '../contexts/IssueContext'
import AdminModal from '../components/Modals/AdminModal'

export default function AdminPanel(){
  const { issues, bulkUpdateStatus, deleteIssue } = useContext(IssueContext)
  const [selected, setSelected] = useState([])
  const [editing, setEditing] = useState(null)
  const toggle = (id)=> setSelected(prev=> prev.includes(id)? prev.filter(x=>x!==id): [...prev,id])

  return (
    <Layout>
      <div className="glass p-4">
        <h2 className="font-bold">Admin Panel</h2>
        <div className="mt-2 flex gap-2">
          <button className="btn-primary" onClick={()=>bulkUpdateStatus(selected,'In Progress')}>Mark In Progress</button>
          <button className="btn-primary" onClick={()=>bulkUpdateStatus(selected,'Resolved')}>Mark Resolved</button>
          <button className="btn-danger" onClick={()=>selected.forEach(id=>deleteIssue(id))}>Delete Selected</button>
        </div>
        <div className="mt-4">
          {issues.map(i=> (
            <div key={i.id} className="glass-card p-3 flex justify-between items-center">
              <div>
                <input type="checkbox" checked={selected.includes(i.id)} onChange={()=>toggle(i.id)} />
                <span className="font-bold ml-2">{i.title}</span>
                <div className="text-sm">{i.status} • {i.priority}</div>
              </div>
              <div className="flex gap-2">
                <button className="btn-primary" onClick={()=>setEditing(i)}>Edit</button>
                <button className="btn-danger" onClick={()=>deleteIssue(i.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
      {editing && <div className="fixed inset-0 flex items-center justify-center p-4"><AdminModal issue={editing} onClose={()=>setEditing(null)} /></div>}
    </Layout>
  )
}
