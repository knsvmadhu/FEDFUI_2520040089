import { STORAGE_KEYS } from '../utils/constants'
import { uid } from '../utils/helpers'

export function seedDefaults(){
  const users = [
    {id: 'admin', name: 'Admin', email: 'admin@cv.local', password: 'admin', role: 'admin'},
    {id: uid(), name: 'Alice', email: 'alice@example.com', password: 'alice', role: 'citizen'}
  ]
  const issues = []
  if(!localStorage.getItem(STORAGE_KEYS.USERS)) localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users))
  if(!localStorage.getItem(STORAGE_KEYS.ISSUES)) localStorage.setItem(STORAGE_KEYS.ISSUES, JSON.stringify(issues))
}
